export default class VArticulos{

    constructor(){
        this.ipArticulo=document.getElementById('ipArticulo_Formulario');
        this.articulos_btidetificardor.getElementById("articulos_btidetificardor")
    }


    salidaFormularioArticulo(){
        return this.ipArticulo.value;
    }
}